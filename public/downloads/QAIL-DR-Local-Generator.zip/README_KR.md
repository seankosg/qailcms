# QAIL CMS 로컬 재해복구 생성기

이 폴더는 QAIL CMS 재해복구 패키지를 **관리자 로컬 PC** 에서 만들기 위한 도구입니다.

## 준비물
1. Node.js LTS (https://nodejs.org)
2. PostgreSQL 17.x client (pg_dump, pg_restore)
3. 운영 DB 접속정보 / 백엔드 URL / 서버 키(service role)
4. 완성 ZIP 을 저장할 로컬 폴더

별도의 npm install, 저장소 clone, Git 은 필요하지 않습니다.
필요한 JS 의존성은 run.bundle.mjs 안에 모두 포함되어 있습니다.

## 실행
- Windows: `QAIL-재해복구-패키지-생성.cmd` 더블클릭
- macOS: `QAIL-재해복구-패키지-생성.command` 더블클릭
  (최초 1회 `chmod +x QAIL-재해복구-패키지-생성.command` 가 필요할 수 있습니다)

두 런처는 동일한 `run.bundle.mjs` 를 호출합니다.

## 포함 범위
- 전체 DB dump (auth 포함, PostgreSQL 17.x custom format)
- 업무 Storage 보관함 7개
- `db-backups` 보관함은 중복이므로 제외합니다

## 주의
- 이 폴더에는 어떤 비밀번호나 서버 키도 저장되어 있지 않습니다. 실행 중에만 입력합니다.
- 완성된 ZIP 과 run_receipt.json 은 반드시 함께 보관하고, QAIL CMS 관리자 화면의
  "로컬 재해복구 패키지" 카드에서 검증하세요.
- 동봉된 supabase/migrations 는 이 생성기 버전이 전제하는 스키마 계약입니다.
