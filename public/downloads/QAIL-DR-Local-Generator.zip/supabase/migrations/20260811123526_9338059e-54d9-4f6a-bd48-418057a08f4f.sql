CREATE OR REPLACE FUNCTION public.spl_hdec_apply(_batch_id uuid, _patches jsonb, _allow_deletes boolean DEFAULT false, _delete_count integer DEFAULT 0)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  p jsonb; s jsonb; it public.spl_items%ROWTYPE;
  v_auth text; v_type text; v_code text; g jsonb;
  v_items int := 0; v_stages int := 0; v_created int := 0;
  v_i0 int; v_s0 int; v_c0 int;
  v_pct numeric; v_min int; v_total int;
  v_write_as boolean; v_write_af boolean;
  v_rejected jsonb := '[]'::jsonb;
BEGIN
  g := public.rcl_grants('SPL','import');
  IF g->>'role' IS NULL OR NOT ((g->>'own')::boolean OR (g->>'own_team')::boolean OR (g->>'other_team')::boolean) THEN
    RAISE EXCEPTION 'SPL import: permission denied';
  END IF;

  IF _delete_count > 0 AND NOT _allow_deletes THEN
    SELECT (value->>'pct')::numeric, (value->>'min_count')::int
      INTO v_pct, v_min FROM public.spl_settings WHERE key = 'delete_guard';
    v_pct := coalesce(v_pct, 5); v_min := coalesce(v_min, 50);
    v_total := greatest(jsonb_array_length(_patches), 1);
    IF _delete_count >= v_min OR (_delete_count::numeric * 100 / v_total) >= v_pct THEN
      RAISE EXCEPTION 'SPL import halted: delete guard tripped (deletes=%, rows=%, threshold pct=%, min=%)',
        _delete_count, v_total, v_pct, v_min;
    END IF;
  END IF;

  PERFORM set_config('spl.change_source', 'hdec_import', true);
  PERFORM set_config('spl.batch_id', coalesce(_batch_id::text, ''), true);

  FOR p IN SELECT * FROM jsonb_array_elements(_patches) LOOP
    v_i0 := v_items; v_s0 := v_stages; v_c0 := v_created;
    BEGIN
      SELECT * INTO it FROM public.spl_items WHERE spl_number = p->>'spl_number';

      IF NOT FOUND THEN
        IF nullif(p->>'plot','') IS NULL THEN
          RAISE EXCEPTION 'SPL import: cannot create % without plot', p->>'spl_number';
        END IF;
        INSERT INTO public.spl_items(spl_number, plot, team, pic, eng, pic_po, eng_po, supplier, created_by, updated_by)
        VALUES (p->>'spl_number', p->>'plot',
          nullif(p->'item'->>'team',''), nullif(p->'item'->>'pic',''), nullif(p->'item'->>'eng',''),
          nullif(p->'item'->>'pic_po',''), nullif(p->'item'->>'eng_po',''), nullif(p->'item'->>'supplier',''),
          auth.uid(), auth.uid())
        ON CONFLICT (spl_number) DO NOTHING;
        v_created := v_created + 1;
        SELECT * INTO it FROM public.spl_items WHERE spl_number = p->>'spl_number';
        IF NOT FOUND THEN
          RAISE EXCEPTION 'SPL import: failed to create %', p->>'spl_number';
        END IF;
      ELSIF p ? 'item' AND jsonb_typeof(p->'item') = 'object' AND (p->'item') <> '{}'::jsonb THEN
        UPDATE public.spl_items t SET
          team    = CASE WHEN p->'item' ? 'team'     THEN nullif(p->'item'->>'team','')     ELSE t.team END,
          pic     = CASE WHEN p->'item' ? 'pic'      THEN nullif(p->'item'->>'pic','')      ELSE t.pic END,
          eng     = CASE WHEN p->'item' ? 'eng'      THEN nullif(p->'item'->>'eng','')      ELSE t.eng END,
          pic_po  = CASE WHEN p->'item' ? 'pic_po'   THEN nullif(p->'item'->>'pic_po','')   ELSE t.pic_po END,
          eng_po  = CASE WHEN p->'item' ? 'eng_po'   THEN nullif(p->'item'->>'eng_po','')   ELSE t.eng_po END,
          supplier= CASE WHEN p->'item' ? 'supplier' THEN nullif(p->'item'->>'supplier','') ELSE t.supplier END,
          -- View 양식 재임포트: Plot 열이 파일에 있을 때만 갱신 (빈칸은 기존 값 유지)
          plot    = CASE WHEN p->'item' ? 'plot' AND nullif(p->'item'->>'plot','') IS NOT NULL
                         THEN p->'item'->>'plot' ELSE t.plot END,
          updated_by = auth.uid()
        WHERE t.id = it.id;
        v_items := v_items + 1;
      END IF;

      FOR s IN SELECT * FROM jsonb_array_elements(coalesce(p->'stages','[]'::jsonb)) LOOP
        v_code := s->>'stage_code';
        SELECT actual_authority, value_type INTO v_auth, v_type
          FROM public.spl_stage_catalog WHERE stage_code = v_code;
        IF v_auth IS NULL THEN
          RAISE EXCEPTION 'SPL import: unknown stage_code %', v_code;
        END IF;

        v_write_as := (s ? 'actual_start')  AND (v_auth = 'HDEC' OR nullif(s->>'actual_start','')  IS NOT NULL);
        v_write_af := (s ? 'actual_finish') AND (v_auth = 'HDEC' OR nullif(s->>'actual_finish','') IS NOT NULL);

        INSERT INTO public.spl_stage_progress(item_id, stage_code, plan_start, actual_start, plan_finish, actual_finish, flag_value, na_flag)
        VALUES (it.id, v_code,
          CASE WHEN s ? 'plan_start'  THEN nullif(s->>'plan_start','')::date  ELSE NULL END,
          CASE WHEN v_write_as        THEN nullif(s->>'actual_start','')::date ELSE NULL END,
          CASE WHEN s ? 'plan_finish' THEN nullif(s->>'plan_finish','')::date ELSE NULL END,
          CASE WHEN v_write_af        THEN nullif(s->>'actual_finish','')::date ELSE NULL END,
          CASE WHEN s ? 'flag_value'  THEN nullif(s->>'flag_value','')        ELSE NULL END,
          CASE WHEN s ? 'na_flag'     THEN coalesce((s->>'na_flag')::boolean,false) ELSE false END)
        ON CONFLICT (item_id, stage_code) DO UPDATE SET
          plan_start    = CASE WHEN s ? 'plan_start'  THEN nullif(s->>'plan_start','')::date  ELSE spl_stage_progress.plan_start END,
          actual_start  = CASE WHEN v_write_as        THEN nullif(s->>'actual_start','')::date ELSE spl_stage_progress.actual_start END,
          plan_finish   = CASE WHEN s ? 'plan_finish' THEN nullif(s->>'plan_finish','')::date ELSE spl_stage_progress.plan_finish END,
          actual_finish = CASE WHEN v_write_af        THEN nullif(s->>'actual_finish','')::date ELSE spl_stage_progress.actual_finish END,
          flag_value    = CASE WHEN s ? 'flag_value'  THEN nullif(s->>'flag_value','')        ELSE spl_stage_progress.flag_value END,
          na_flag       = CASE WHEN s ? 'na_flag'     THEN coalesce((s->>'na_flag')::boolean,false) ELSE spl_stage_progress.na_flag END,
          updated_by = auth.uid();
        v_stages := v_stages + 1;
      END LOOP;

      PERFORM public.spl_assert_row_rules(it.id);
    EXCEPTION WHEN OTHERS THEN
      v_items := v_i0; v_stages := v_s0; v_c0 := v_c0;
      v_created := v_c0;
      v_rejected := v_rejected || jsonb_build_object(
        'key', p->>'spl_number',
        'reason_code', CASE WHEN SQLSTATE = '23514' THEN 'PRECONDITION_NOT_MET' ELSE 'ROW_ERROR' END,
        'message', SQLERRM);
    END;
  END LOOP;

  PERFORM set_config('spl.change_source', 'app', true);
  PERFORM set_config('spl.batch_id', '', true);

  RETURN jsonb_build_object('items_updated', v_items, 'items_created', v_created,
    'stages_upserted', v_stages, 'rejected', v_rejected, 'unmatched', to_jsonb(ARRAY[]::text[]));
END;
$function$;